﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace notatnik
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Zapisz(object sender, RoutedEventArgs e)
        {
            SaveFileDialog oknoZapisu = new SaveFileDialog();
            oknoZapisu.Filter = "PlainText | *.txt";
            oknoZapisu.Title = "Zapisz jako";
            if (oknoZapisu.ShowDialog() == true)
            {
                File.WriteAllText(oknoZapisu.FileName, text.Text);
            }
        }

        private void Otworz(object sender, RoutedEventArgs e)
        {
            OpenFileDialog oknoOtworz = new OpenFileDialog();
            oknoOtworz.Filter = "PlainText | *.txt";
            oknoOtworz.Title = "Otworz";
            if (oknoOtworz.ShowDialog() == true)
            {
                text.Text = File.ReadAllText(oknoOtworz.FileName);
            }
        }

        private void Nowy(object sender, RoutedEventArgs e)
        {
            if (text.Text != null)
            {
                if (MessageBox.Show("Czy chcesz zapisac plik?", "Zapisz plik", MessageBoxButton.YesNo, MessageBoxImage.Question) == MessageBoxResult.Yes)
                {
                    SaveFileDialog oknoZapisu = new SaveFileDialog();
                    oknoZapisu.Filter = "PlainText | *.txt";
                    oknoZapisu.Title = "Zapisz jako";
                    if (oknoZapisu.ShowDialog() == true)
                    {
                        File.WriteAllText(oknoZapisu.FileName, text.Text);
                        text.Clear();
                    }
                    text.Clear();
                }
            }
        }

        private void ZapiszW(object sender, RoutedEventArgs e)
        {

        }

        private void Modalny(object sender, RoutedEventArgs e)
        {
            Window okno = new Window();
            okno.ShowDialog();
        }

        private void Niemodalny(object sender, RoutedEventArgs e)
        {
            Window okno = new Window();
            okno.Show();
        }

        private void Info(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Testowanie notatnika", "Informacje o programie", MessageBoxButton.OK, MessageBoxImage.Information);
        }

        private void kopiuj(object sender, RoutedEventArgs e)
        {
            text.Copy();
        }

        private void wytnij(object sender, RoutedEventArgs e)
        {
            text.Cut();
        }

        private void wklej(object sender, RoutedEventArgs e)
        {
            text.Paste();
        }

        private void czerwony(object sender, RoutedEventArgs e)
        {
            text.Foreground = Brushes.Red;
        }

        private void plus(object sender, RoutedEventArgs e)
        {
            text.FontSize += 1;
        }

        private void minus(object sender, RoutedEventArgs e)
        {
            text.FontSize -= 1;
        }

        private void zmiana(object sender, RoutedEventArgs e)
        {
            if (Zmiana.IsChecked)
            {
                text.Foreground = Brushes.Black;
                text.Background = Brushes.White;
            }
            else
            {
                text.Foreground = Brushes.White;
                text.Background = Brushes.Black;
            }
        }
    }
}
